<div class="mk-custom-box">
	<div class="box-holder">
		<div class="clear"></div>
	</div>
</div> 